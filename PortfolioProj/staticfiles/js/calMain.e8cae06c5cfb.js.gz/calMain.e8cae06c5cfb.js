var calculator = new Vue({
    delimiters: ["[[", "]]"],
    el: '#calculator',
    data: {
      message: 'Hello Vue!'
    }
})
